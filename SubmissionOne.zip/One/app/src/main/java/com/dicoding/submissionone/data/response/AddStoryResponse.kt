package com.dicoding.submissionone.data.response

data class AddStoryResponse(
    val error: String,
    val message: String
)
