package com.dicoding.submissionone.data.response

data class UserData(
    val name: String,
    val token: String,
    val isLogin: Boolean
)
