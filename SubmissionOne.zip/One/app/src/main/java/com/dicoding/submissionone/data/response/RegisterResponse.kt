package com.dicoding.submissionone.data.response

data class RegisterResponse(
    val error: String,
    val message: String
)
